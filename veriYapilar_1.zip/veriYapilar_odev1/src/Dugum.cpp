/**
 * Dugum.cpp
 * Dugumun adresi ve verisi diger atamak
 * 1-A
 * Birinci odev
 * 7/19/2023 Tarihta olusturdu
 * Yazan: Asem Hagi Hasan. Mail adresi:asem.hagihasan@ogr.sakarya.edu.tr
 */
#include "Dugum.hpp"

Dugum::Dugum(int veri)
{
    this->veri = veri;
    this->sonraki = 0;
}