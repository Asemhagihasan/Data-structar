/**
 * main.cpp
 * yazdir metedo cagirmak
 * 1-A
 * Birinci odev
 * 7/19/2023 Tarihta olusturdu
 * Yazan: Asem Hagi Hasan. Mail adresi:asem.hagihasan@ogr.sakarya.edu.tr
 * ogrenci No:B201210567
 */

#include <iostream>
#include <iostream>
#include "Listeler.hpp"
using namespace std;

int main()
{
    Listeler liste;
    liste.yazdir();
}